﻿FileExplorer v1.0.2 Portable
============================

Contents:
- FileExplorer_v1.0.2.exe
- README.txt
- REVISION.txt

How to run:
1. Keep this folder writable.
2. Double-click FileExplorer_v1.0.2.exe.

Portable data files are created in this same folder on first run:
- settings.ini
- session.ini
- sort_settings.csv
- flyout_favourites.csv
- regular_favourites.csv

Notes:
- Target OS: Windows 11 x64
- Build: native Win32 C++20 (MSVC), x64
- No installer required
